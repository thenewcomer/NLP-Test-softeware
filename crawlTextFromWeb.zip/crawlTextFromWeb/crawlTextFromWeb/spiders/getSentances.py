import scrapy 
from twisted.internet.error import DNSLookupError
from scrapy.spidermiddlewares.httperror import HttpError
from scrapy.linkextractors import LinkExtractor
from twisted.internet.error import TimeoutError


url = 'https://en.wikipedia.org/wiki/Main_Page/'
urlHead = 'https://en.wikipedia.org'
filenum = 0
usedFileName = '/Users/xiangyuanxin/Developer/Scrapy/start/crawlTextFromWeb/usedUrls.txt'
allNewUrls = []
usedUrls = []
stopWords = []
totalPagesCrawl = 10000
pageCount = 0
filename = "textfile" + ".txt"


class getScentances(scrapy.Spider):
    handle_httpstatus_list = [404, 401, 403, 500, 502, 503, 504]
    name = "crawlText"
    global stopWords
    stopfile = open("/Users/xiangyuanxin/Developer/Scrapy/start/crawlTextFromWeb/stopwords.txt")
    for line in stopfile:
            stopWords.append(line)
    print("-----------------", stopWords)
    def start_requests(self):
            global usedUrls
            request = scrapy.Request(url=url, callback=self.parse, dont_filter=True, errback=self.errback_httpbin)
            request.cookies['over18'] = 1
            request.headers['User-Agent'] = ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36')
            with open(usedFileName) as usedfile:
                usedUrls = usedfile.readlines()
                usedUrls = [x.strip() for x in usedUrls]
            yield request

    def parse(self, response):
            global pageCount
            global allNewUrls
            global usedUrls
            hasAttributeError = False
            if response.status == 200:
                pageCount = pageCount + 1
                print("page number is : ", pageCount)
                '''
                    get text of this page and save it to file
                    '''
                try:
                    text = response.xpath('//body//text()').extract()
                except AttributeError:
                    hasAttributeError = True
                    print("Have AttributeError = ", hasAttributeError)
                if not hasAttributeError:
                    global filenum
                    filenum = filenum + 1
                    with open(filename, 'a') as textfile:
                        for i in range(0,len(text)):
                            textfile.write(text[i].encode('utf-8'))
                        textfile.write("\n".encode('utf-8'))
                    '''
                        get all the urls of this page and delete the used ones
                        use these new urls to craw
                    '''
                    validUrl = True
                    if pageCount < totalPagesCrawl:
                        urls = response.xpath('//*//@href').extract()
                        for i in range(0, len(urls)):
                            if "http" not in urls[i]:
                                urls[i] = urlHead + urls[i]
                        newUrls = list(set(urls) - set(usedUrls))
                        for i in range(0, len(newUrls)):
                            for j in range(0, len(stopWords)):
                                if stopWords[j].strip() in newUrls[i]:
                                        validUrl = False
                            if validUrl:
                                allNewUrls.append(newUrls[i])
                    if len(allNewUrls) <= 0:
                        with open(usedFileName, 'wb') as saveusedfile:
                            for i_used in range(0, len(usedUrls)):
                                saveusedfile.write((usedUrls[i_used] + "\n").encode('utf-8'))

            if len(allNewUrls) > 0:
                print("here is nextUrl ------------", allNewUrls[0])
                nextUrl = allNewUrls[0]
                del allNewUrls[0]
                usedUrls.append(nextUrl)
                request = scrapy.Request(url=nextUrl, callback=self.parse, dont_filter=True, errback=self.errback_httpbin)
                yield request

    def errback_httpbin(self, failure):
            if failure.check(HttpError):
                    print("HttpError")
            elif failure.check(DNSLookupError):
                    request = failure.request
                    self.logger.info('DNSLookupError on %s', request.url)
            elif failure.check(TimeoutError):
                    print("TimeoutError")
            if len(allNewUrls) > 0:
                    nextUrl = allNewUrls[0]
                    del allNewUrls[0]
                    request = scrapy.Request(url=nextUrl, callback=self.parse, dont_filter=True, errback=self.errback_httpbin)
                    yield request







